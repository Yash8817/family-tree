<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/head/create', 'HeadController@create')->name('head.create');
Route::post('/head/store', 'HeadController@store')->name('head.store');

Route::get('/heads', 'HeadController@index')->name('head.index');
Route::get('/head/{id}', 'HeadController@show')->name('head.show');


Route::get('/head/{id}/members/create', 'MemberController@create')->name('members.create');
Route::post('/head/{id}/members/store', 'MemberController@store')->name('members.store');
Route::get('/head/create', 'HeadController@create')->name('head.create');
// Route::get('/heads', 'HeadController@index')->name('head.index');


