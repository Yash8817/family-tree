<!DOCTYPE html>
<html>
<head>
    <title>Add Head of Family</title>
</head>
<body>
    <h2>Add Head of Family</h2>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('head.store')); ?>">
    @csrf
        <label>Name: <input type="text" name="name" required></label><br><br>
        <label>Surname: <input type="text" name="surname" required></label><br><br>
        <label>Birthdate: <input type="date" name="birthdate" required></label><br><br>
        <label>Mobile No: <input type="text" name="mobile_no" required></label><br><br>
        <label>Address: <textarea name="address" required></textarea></label><br><br>
        <label>State: 
            <select name="state" required>
                <option value="">Select State</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Maharashtra">Maharashtra</option>
            </select>
        </label><br><br>
        <label>City: 
            <select name="city" required>
                <option value="">Select City</option>
                <option value="Ahmedabad">Ahmedabad</option>
                <option value="Surat">Surat</option>
            </select>
        </label><br><br>
        <label>Pincode: <input type="text" name="pincode" required></label><br><br>
        <label>Marital Status:
            <select name="is_married" id="is_married" onchange="toggleWeddingDate()" required>
                <option value="0">Unmarried</option>
                <option value="1">Married</option>
            </select>
        </label><br><br>
        <div id="wedding_date_div" style="display: none;">
            <label>Wedding Date: <input type="date" name="wedding_date"></label><br><br>
        </div>

        <label>Hobbies: 
            <input type="text" name="hobbies[]" placeholder="Enter Hobby">
            <button type="button" onclick="addHobby()">Add Hobby</button>
            <div id="moreHobbies"></div>
        </label><br><br>

        <!-- <label>Photo: <input type="file" name="photo"></label><br><br> -->

        <button type="submit">Submit</button>
    </form>

    <p>
    <a href="<?php echo e(route('head.index')); ?>" style="background:#ccc; color:#000; padding:8px 15px; text-decoration:none; border-radius:5px;">
        ← Back to Head List
    </a>
</p>


    <script>
        function toggleWeddingDate() {
            var marital = document.getElementById("is_married").value;
            document.getElementById("wedding_date_div").style.display = marital == 1 ? "block" : "none";
        }

        function addHobby() {
            var container = document.getElementById("moreHobbies");
            var input = document.createElement("input");
            input.type = "text";
            input.name = "hobbies[]";
            input.placeholder = "Enter Hobby";
            container.appendChild(document.createElement("br"));
            container.appendChild(input);
        }
    </script>
</body>
</html>
