<h2><?php echo e($head->name); ?> <?php echo e($head->surname); ?>'s Family</h2>

<p><strong>Mobile:</strong> <?php echo e($head->mobile_no); ?></p>
<p><strong>Address:</strong> <?php echo e($head->address); ?>, <?php echo e($head->city); ?>, <?php echo e($head->state); ?> - <?php echo e($head->pincode); ?></p>
<p><strong>Birthdate:</strong> <?php echo e($head->birthdate); ?></p>
<p><strong>Marital Status:</strong> <?php echo e($head->is_married ? 'Married' : 'Unmarried'); ?></p>
<?php if($head->is_married): ?>
    <p><strong>Wedding Date:</strong> <?php echo e($head->wedding_date); ?></p>
<?php endif; ?>
<p><strong>Hobbies:</strong> <?php echo e($head->hobbies); ?></p>
<p><strong>Photo:</strong><br>
<?php if($head->photo): ?>
    <img src="<?php echo e(asset($head->photo)); ?>" width="100">
<?php endif; ?>
</p>

<h3>Family Members</h3>

<?php if($head->members->count()): ?>
    <ul>
        <?php $__currentLoopData = $head->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($member->name); ?> | Born: <?php echo e($member->birthdate); ?> | 
                <?php echo e($member->is_married ? 'Married on ' . $member->wedding_date : 'Unmarried'); ?> | 
                Education: <?php echo e($member->education); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <p>No members added yet.</p>
<?php endif; ?>

<p>
    <a href="<?php echo e(route('members.create', $head->id)); ?>">+ Add Family Member</a>
</p>
