<h2>Add Family Member for <?php echo e($head->name); ?> <?php echo e($head->surname); ?></h2>

<?php if($errors->any()): ?>
    <div style="color: red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('members.store', $head->id)); ?>" method="POST">
    @csrf
    <label>Name: <input type="text" name="name" required></label><br><br>
    <label>Birthdate: <input type="date" name="birthdate" required></label><br><br>

    <label>Marital Status:
        <select name="is_married" id="is_married" onchange="toggleWedding()" required>
            <option value="0">Unmarried</option>
            <option value="1">Married</option>
        </select>
    </label><br><br>

    <div id="wedding_div" style="display: none;">
        <label>Wedding Date: <input type="date" name="wedding_date"></label><br><br>
    </div>

    <label>Education: <input type="text" name="education"></label><br><br>
    <!-- <label>Photo: <input type="file" name="photo"></label><br><br> -->

    <button type="submit">Add Member</button>
</form>

<script>
function toggleWedding() {
    document.getElementById('wedding_div').style.display =
        document.getElementById('is_married').value == '1' ? 'block' : 'none';
}
</script>
