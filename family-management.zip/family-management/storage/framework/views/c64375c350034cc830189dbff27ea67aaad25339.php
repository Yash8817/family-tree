<h2>Head of Family List</h2>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>Name</th>
            <th>Members</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $heads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($head->name); ?> <?php echo e($head->surname); ?></td>
            <td><?php echo e($head->members_count); ?></td>
            <td><a href="<?php echo e(route('head.show', $head->id)); ?>">View Family</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<p>
    <a href="<?php echo e(route('head.create')); ?>" style="background:#4CAF50; color:white; padding:8px 15px; text-decoration:none; border-radius:5px;">
        + Add Head of Family
    </a>
</p>
