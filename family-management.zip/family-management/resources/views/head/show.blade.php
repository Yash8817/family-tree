<h2>{{ $head->name }} {{ $head->surname }}'s Family</h2>

<p><strong>Mobile:</strong> {{ $head->mobile_no }}</p>
<p><strong>Address:</strong> {{ $head->address }}, {{ $head->city }}, {{ $head->state }} - {{ $head->pincode }}</p>
<p><strong>Birthdate:</strong> {{ $head->birthdate }}</p>
<p><strong>Marital Status:</strong> {{ $head->is_married ? 'Married' : 'Unmarried' }}</p>
@if($head->is_married)
    <p><strong>Wedding Date:</strong> {{ $head->wedding_date }}</p>
@endif
<p><strong>Hobbies:</strong> {{ $head->hobbies }}</p>
<p><strong>Photo:</strong><br>
@if($head->photo)
    <img src="{{ asset($head->photo) }}" width="100">
@endif
</p>

<h3>Family Members</h3>

@if($head->members->count())
    <ul>
        @foreach($head->members as $member)
            <li>
                {{ $member->name }} | Born: {{ $member->birthdate }} | 
                {{ $member->is_married ? 'Married on ' . $member->wedding_date : 'Unmarried' }} | 
                Education: {{ $member->education }}
            </li>
        @endforeach
    </ul>
@else
    <p>No members added yet.</p>
@endif

<p>
    <a href="{{ route('members.create', $head->id) }}">+ Add Family Member</a>
</p>
