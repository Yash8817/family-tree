<h2>Head of Family List</h2>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>Name</th>
            <th>Members</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    @foreach($heads as $head)
        <tr>
            <td>{{ $head->name }} {{ $head->surname }}</td>
            <td>{{ $head->members_count }}</td>
            <td><a href="{{ route('head.show', $head->id) }}">View Family</a></td>
        </tr>
    @endforeach
    </tbody>
</table>

<p>
    <a href="{{ route('head.create') }}" style="background:#4CAF50; color:white; padding:8px 15px; text-decoration:none; border-radius:5px;">
        + Add Head of Family
    </a>
</p>
