<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    public function head()
    {
        return $this->belongsTo('App\Head');
    }
}
