<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Head; // Make sure model is imported
use Illuminate\Support\Facades\Storage;
// use App\Head;
use App\Member;
use Validator; // Add this at the top


class HeadController extends Controller
{


    public function create()
    {
        return view('head.create');
    }
    public function index()
    {
        $heads = Head::withCount('members')->get();
        return view('head.index', compact('heads'));
    }

    public function show($id)
    {
        $head = Head::with('members')->findOrFail($id);
        return view('head.show', compact('head'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'birthdate' => 'required|date|before:-21 years',
            'mobile_no' => 'required|digits:10',
            'address' => 'required|string',
            'state' => 'required|string',
            'city' => 'required|string',
            'pincode' => 'required|digits:6',
            'is_married' => 'required|boolean',
            'wedding_date' => 'nullable|date|required_if:is_married,1',
            'hobbies' => 'nullable|array',
            'hobbies.*' => 'nullable|string|max:255',
            // 'photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $head = new Head();
        $head->name = $request->name;
        $head->surname = $request->surname;
        $head->birthdate = $request->birthdate;
        $head->mobile_no = $request->mobile_no;
        $head->address = $request->address;
        $head->state = $request->state;
        $head->city = $request->city;
        $head->pincode = $request->pincode;
        $head->is_married = $request->is_married;
        $head->wedding_date = $request->wedding_date;

        // Store hobbies as comma-separated string (Laravel 5.4 lacks JSON support)
        $head->hobbies = $request->hobbies ? implode(',', $request->hobbies) : null;

        // // Photo upload
        // if ($request->hasFile('photo')) {
        //     $filename = time() . '_' . $request->file('photo')->getClientOriginalName();
        //     $request->file('photo')->move(public_path('uploads'), $filename);
        //     $head->photo = 'uploads/' . $filename;
        // }

        $head->save();

        return redirect()->back()->with('success', 'Head of Family added successfully!');
    }
}
