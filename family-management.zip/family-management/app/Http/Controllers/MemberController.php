<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Head;
use App\Member;
use Validator; 


class MemberController extends Controller
{
    public function create($id)
    {
        $head = Head::findOrFail($id);
        return view('members.create', compact('head'));
    }

    public function store(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'birthdate' => 'required|date',
            'is_married' => 'required|boolean',
            'wedding_date' => 'nullable|date|required_if:is_married,1',
            'education' => 'nullable|string|max:255',
        ]);
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $member = new Member();
        $member->head_id = $id;
        $member->name = $request->name;
        $member->birthdate = $request->birthdate;
        $member->is_married = $request->is_married;
        $member->wedding_date = $request->wedding_date;
        $member->education = $request->education;

        // if ($request->hasFile('photo')) {
        //     $filename = time() . '_' . $request->file('photo')->getClientOriginalName();
        //     $request->file('photo')->move(public_path('uploads'), $filename);
        //     $member->photo = 'uploads/' . $filename;
        // }

        $member->save();

        return redirect()->route('head.show', $id)->with('success', 'Family member added!');
    }
}
